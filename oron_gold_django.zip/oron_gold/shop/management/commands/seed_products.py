from django.core.management.base import BaseCommand

from shop.models import Product

DATA = [
    dict(code="CPO", grade_label="GRADE A CPO", tag="Cold-Pressed", name="Crude Palm Oil (CPO)",
         description="Unbleached, beta-carotene rich, deep natural ruby-red oil cold-pressed from coastal Akwa Ibom groves. Naturally loaded with Vitamin A & E with no chemical bleaching.",
         specs=[["Free Fatty Acid (FFA):", "< 2.0%"], ["Peroxide Value:", "< 10 meq/kg"], ["Moisture & Impurities:", "< 0.15%"], ["Iodine Value:", "50 – 55 Wijs"]],
         packaging=["5L Can (₦19,500)", "25L Jerrycan (₦88,000)", "200L Drum", "1,000L IBC"],
         accent="emerald", featured=True, featured_label="Flagship Red Harvest", price_prefix="Starting at",
         price=4500, price_unit="/ 1L Flask", price_note="Fresh Mill Batch", sort_order=1),
    dict(code="RBD", grade_label="RBD FRACTION", tag="High Stability", name="Refined Palm Oil (RBD)",
         description="Refined, bleached, and deodorized neutral golden culinary oil. Crystal clear clarity with an exceptionally high smoke point for commercial kitchens, snack fryers, and bakeries.",
         specs=[["Free Fatty Acid (FFA):", "< 0.10%"], ["Smoke Point:", "235°C (455°F)"], ["Color (Lovibond):", "< 3.0 Red"], ["Trans-Fatty Acids:", "0.0% Non-Hydrogenated"]],
         packaging=["25L Jerrycan", "200L Steel Drum", "1,000L IBC Tote", "30MT Road Tanker"],
         accent="amber", price_prefix="Commercial Tier", price=92000, price_unit="/ 25L",
         price_note="Zero Odor / Clear", sort_order=2),
    dict(code="PKO", grade_label="HIGH-LAURIC SEED", tag="Oleochemical", name="Palm Kernel Oil (PKO)",
         description="Cold-pressed palm kernel seed extract, clarity-filtered to a clean golden-amber hue. Rich in lauric acid, making it critical for premium soaps, skin cosmetics, and confectionery glazes.",
         specs=[["Free Fatty Acid (FFA):", "< 3.0%"], ["Lauric Acid (C12):", "48 – 52%"], ["Iodine Value:", "17 – 19 Wijs"], ["Saponification:", "245 – 255 mg KOH/g"]],
         packaging=["25L Jerrycan", "200L Steel Drum", "1,000L IBC Tote"],
         accent="teal", price_prefix="Cosmetic / Food Grade", price=98500, price_unit="/ 25L",
         price_note="COA Included", sort_order=3),
]


class Command(BaseCommand):
    help = "Create or update the three starter products"

    def handle(self, *args, **opts):
        for row in DATA:
            Product.objects.update_or_create(code=row["code"], defaults=row)
        self.stdout.write(self.style.SUCCESS(f"Seeded {len(DATA)} products"))
