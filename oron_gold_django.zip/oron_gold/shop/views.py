from django.http import JsonResponse
from django.shortcuts import redirect, render
from django.views.decorators.http import require_POST

from .forms import InquiryForm, SampleOrderForm
from .models import SAMPLE_PRICES, Product, SampleOrder, transit_fee


def home(request):
    return render(request, "shop/home.html", {
        "products": Product.objects.filter(is_active=True),
        "inquiry_sent": request.GET.get("sent") == "1",
        "inquiry_error": request.GET.get("error") == "1",
    })


@require_POST
def inquiry(request):
    form = InquiryForm(request.POST)
    if form.is_valid():
        form.save()
        return redirect("/?sent=1#contact")
    return redirect("/?error=1#contact")


@require_POST
def sample_order(request):
    form = SampleOrderForm(request.POST)
    if not form.is_valid():
        return JsonResponse({"ok": False, "errors": form.errors}, status=400)
    d = form.cleaned_data
    price = SAMPLE_PRICES[d["sampleSize"]]  # computed server-side, never trusted from the client
    fee = transit_fee(d["sampleState"])
    order = SampleOrder.objects.create(
        grade=d["oilGrade"], size=d["sampleSize"], name=d["sampleName"], business=d["sampleBiz"],
        phone=d["samplePhone"], state=d["sampleState"], address=d["sampleAddress"],
        purpose=d["samplePurpose"], sample_price=price, transit_fee=fee, total=price + fee,
    )
    return JsonResponse({"ok": True, "ref": order.ref, "state": order.state, "phone": order.phone})
