
  // Simple state management for interactive Sample Request modal
  const sampleModal = document.getElementById('sampleModal');
  const sampleOrderForm = document.getElementById('sampleOrderForm');
  const sampleSuccessNotice = document.getElementById('sampleSuccessNotice');

  function openSampleModal(oilGrade) {
    sampleModal.classList.remove('hidden');
    document.body.classList.add('overflow-hidden');
    sampleSuccessNotice.classList.add('hidden');
    sampleOrderForm.classList.remove('hidden');

    if (oilGrade === 'TRIPLE') {
      const tripleRadio = document.querySelector('input[name="sampleSize"][value="triple"]');
      if (tripleRadio) {
        tripleRadio.checked = true;
      }
    } else if (oilGrade) {
      const gradeRadio = document.querySelector(`input[name="oilGrade"][value="${oilGrade}"]`);
      if (gradeRadio) {
        gradeRadio.checked = true;
        updateSelectedGrade(oilGrade);
      }
    }
    updatePricing();
  }

  function closeSampleModal() {
    sampleModal.classList.add('hidden');
    document.body.classList.remove('overflow-hidden');
  }

  // Backdrop click to dismiss
  sampleModal.addEventListener('click', function(e) {
    if (e.target === sampleModal) {
      closeSampleModal();
    }
  });

  // Escape key to dismiss
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && !sampleModal.classList.contains('hidden')) {
      closeSampleModal();
    }
  });

  function updateSelectedGrade(grade) {
    ['cpo', 'rbd', 'pko'].forEach(g => {
      const el = document.getElementById(`label-grade-${g}`);
      if (el) {
        if (g === grade.toLowerCase()) {
          el.classList.add('border-primary', 'bg-primary/5');
          el.classList.remove('border-outline-variant/50');
        } else {
          el.classList.remove('border-primary', 'bg-primary/5');
          el.classList.add('border-outline-variant/50');
        }
      }
    });
  }

  function updatePricing() {
    const selectedSizeInput = document.querySelector('input[name="sampleSize"]:checked');
    const samplePrice = selectedSizeInput ? parseInt(selectedSizeInput.dataset.price || 1500) : 1500;
    
    // Highlight selected size card
    ['250', '500', 'triple'].forEach(s => {
      const card = document.getElementById(`tier-size-${s}`);
      if (card) {
        if (selectedSizeInput && selectedSizeInput.value === s) {
          card.classList.add('border-primary', 'bg-primary/5');
          card.classList.remove('border-outline-variant/50');
        } else {
          card.classList.remove('border-primary', 'bg-primary/5');
          card.classList.add('border-outline-variant/50');
        }
      }
    });

    const stateSelect = document.getElementById('sampleState');
    const selectedState = stateSelect ? stateSelect.value : 'Lagos';
    
    // Estimate transit fee: Lagos is ₦1,200, Akwa Ibom is ₦800, other states ₦1,800
    let transitFee = 1800;
    if (selectedState === 'Lagos') {
      transitFee = 1200;
    } else if (selectedState === 'Akwa Ibom') {
      transitFee = 800;
    }

    const total = samplePrice + transitFee;

    const summarySamplePrice = document.getElementById('summarySamplePrice');
    const summaryTransitFee = document.getElementById('summaryTransitFee');
    const summaryTotalPrice = document.getElementById('summaryTotalPrice');

    if (summarySamplePrice) summarySamplePrice.innerText = `₦${samplePrice.toLocaleString()}`;
    if (summaryTransitFee) summaryTransitFee.innerText = `₦${transitFee.toLocaleString()}`;
    if (summaryTotalPrice) summaryTotalPrice.innerText = `₦${total.toLocaleString()}`;
  }

  async function handleSampleSubmit(e) {
    e.preventDefault();
    const form = e.target;
    const btn = form.querySelector('button[type="submit"]');
    btn.disabled = true;
    try {
      const res = await fetch(form.dataset.url, {
        method: 'POST',
        body: new FormData(form),
        headers: { 'X-Requested-With': 'XMLHttpRequest' },
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error('Invalid submission');
      document.getElementById('confirmedPhone').innerText = data.phone;
      document.getElementById('confirmedState').innerText = data.state;
      document.getElementById('sampleRef').innerText = data.ref;
      sampleOrderForm.classList.add('hidden');
      sampleSuccessNotice.classList.remove('hidden');
      form.reset();
      updatePricing();
    } catch (err) {
      alert('Sorry, we could not submit your sample request. Please check the fields and try again.');
    } finally {
      btn.disabled = false;
    }
  }
