from django.contrib import admin

from .models import OrderInquiry, Product, SampleOrder


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ("name", "code", "price", "featured", "is_active", "sort_order")
    list_editable = ("is_active", "sort_order")


@admin.register(SampleOrder)
class SampleOrderAdmin(admin.ModelAdmin):
    list_display = ("ref", "name", "business", "grade", "size", "state", "total", "status", "created_at")
    list_filter = ("status", "grade", "state")
    list_editable = ("status",)
    search_fields = ("name", "business", "phone")


@admin.register(OrderInquiry)
class OrderInquiryAdmin(admin.ModelAdmin):
    list_display = ("full_name", "phone", "customer_type", "product_quantity", "handled", "created_at")
    list_filter = ("handled", "customer_type")
    list_editable = ("handled",)
    search_fields = ("full_name", "email", "phone")
