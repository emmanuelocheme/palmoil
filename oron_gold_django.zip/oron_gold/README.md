# Oron Gold – Django site (from Google Stitch export)

    python -m venv venv && source venv/bin/activate
    pip install -r requirements.txt
    python manage.py makemigrations shop
    python manage.py migrate
    python manage.py seed_products
    python manage.py createsuperuser
    python manage.py runserver

Site: http://127.0.0.1:8000/  ·  Admin: /admin/ (edit products, view sample orders & inquiries)

Env vars for production: DJANGO_SECRET_KEY, DJANGO_DEBUG=0, DJANGO_ALLOWED_HOSTS.
Tailwind and fonts load from CDNs, as in the Stitch export.
