from django.urls import path

from . import views

app_name = "shop"

urlpatterns = [
    path("", views.home, name="home"),
    path("inquiry/", views.inquiry, name="inquiry"),
    path("sample-order/", views.sample_order, name="sample_order"),
]
