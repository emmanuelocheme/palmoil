from django import forms

from .models import OrderInquiry, SampleOrder


class InquiryForm(forms.ModelForm):
    class Meta:
        model = OrderInquiry
        fields = ["full_name", "email", "phone", "customer_type", "product_quantity", "message"]


class SampleOrderForm(forms.Form):
    """Field names match the element names/ids used by the modal markup."""
    oilGrade = forms.ChoiceField(choices=SampleOrder.GRADES)
    sampleSize = forms.ChoiceField(choices=SampleOrder.SIZES)
    sampleName = forms.CharField(max_length=120)
    sampleBiz = forms.CharField(max_length=160)
    samplePhone = forms.CharField(max_length=30)
    sampleState = forms.CharField(max_length=40)
    sampleAddress = forms.CharField(max_length=255)
    samplePurpose = forms.ChoiceField(choices=SampleOrder.PURPOSES)
