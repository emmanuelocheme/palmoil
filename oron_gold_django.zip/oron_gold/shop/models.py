from django.db import models

# Tailwind class sets per accent colour (full strings so the Tailwind CDN picks them up)
ACCENTS = {
    "emerald": {"tag": "bg-tertiary/10 text-tertiary", "box": "bg-emerald-50 border-emerald-200/80",
                "icon": "text-emerald-700", "text": "text-emerald-900"},
    "amber": {"tag": "bg-amber-500/10 text-secondary", "box": "bg-amber-50 border-amber-200/80",
              "icon": "text-secondary", "text": "text-[#663500]"},
    "teal": {"tag": "bg-tertiary/10 text-tertiary", "box": "bg-teal-50 border-teal-200/80",
             "icon": "text-tertiary", "text": "text-tertiary"},
}

SAMPLE_PRICES = {"250": 1500, "500": 2800, "triple": 4500}


def transit_fee(state: str) -> int:
    return {"Lagos": 1200, "Akwa Ibom": 800}.get(state, 1800)


class Product(models.Model):
    code = models.SlugField(max_length=10, unique=True, help_text="CPO / RBD / PKO (used by the sample modal)")
    grade_label = models.CharField(max_length=40, help_text="e.g. GRADE A CPO")
    tag = models.CharField(max_length=40, blank=True, help_text="e.g. Cold-Pressed")
    name = models.CharField(max_length=120)
    description = models.TextField()
    specs = models.JSONField(default=list, help_text='[["Free Fatty Acid (FFA):", "< 2.0%"], ...] (first row is highlighted)')
    packaging = models.JSONField(default=list, help_text='["5L Can (₦19,500)", "200L Drum", ...]')
    accent = models.CharField(max_length=10, choices=[(k, k) for k in ACCENTS], default="emerald")
    featured = models.BooleanField(default=False)
    featured_label = models.CharField(max_length=40, blank=True)
    price_prefix = models.CharField(max_length=40, help_text="e.g. Starting at / Commercial Tier")
    price = models.PositiveIntegerField(help_text="Naira")
    price_unit = models.CharField(max_length=40, help_text="e.g. / 25L")
    price_note = models.CharField(max_length=60, blank=True)
    sort_order = models.PositiveSmallIntegerField(default=0)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["sort_order", "id"]

    def __str__(self):
        return self.name

    @property
    def style(self):
        return ACCENTS[self.accent]


class SampleOrder(models.Model):
    GRADES = [("CPO", "Crude Palm"), ("RBD", "Refined Palm"), ("PKO", "Palm Kernel")]
    SIZES = [("250", "250ml"), ("500", "500ml"), ("triple", "Triple kit")]
    PURPOSES = [("catering", "Commercial Kitchen & Catering Trial"), ("cosmetic", "Cosmetics & Soap"),
                ("fmcg", "FMCG Bakery & Industrial Snack"), ("lab", "Independent Laboratory Assay"),
                ("household", "Household Kitchen Trial")]
    STATUSES = [("new", "New"), ("dispatched", "Dispatched"), ("delivered", "Delivered"), ("cancelled", "Cancelled")]

    grade = models.CharField(max_length=3, choices=GRADES)
    size = models.CharField(max_length=10, choices=SIZES)
    name = models.CharField(max_length=120)
    business = models.CharField(max_length=160)
    phone = models.CharField(max_length=30)
    state = models.CharField(max_length=40)
    address = models.CharField(max_length=255)
    purpose = models.CharField(max_length=20, choices=PURPOSES)
    sample_price = models.PositiveIntegerField()
    transit_fee = models.PositiveIntegerField()
    total = models.PositiveIntegerField()
    status = models.CharField(max_length=12, choices=STATUSES, default="new")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    @property
    def ref(self):
        return f"SMP-{8000 + (self.pk or 0)}"

    def __str__(self):
        return f"{self.ref} – {self.name}"


class OrderInquiry(models.Model):
    CUSTOMER_TYPES = [("household", "Household Kitchen (1L - 5L)"),
                      ("restaurant", "Restaurant / Catering / Hotel (25L+)"),
                      ("industrial", "Industrial Wholesale / FMCG Drums (200L - 1000L)"),
                      ("export", "Export Forwarder / Bulk Repacker")]

    full_name = models.CharField(max_length=120)
    email = models.EmailField()
    phone = models.CharField(max_length=30)
    customer_type = models.CharField(max_length=20, choices=CUSTOMER_TYPES)
    product_quantity = models.CharField(max_length=200)
    message = models.TextField(blank=True)
    handled = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        verbose_name_plural = "order inquiries"

    def __str__(self):
        return f"{self.full_name} – {self.product_quantity[:40]}"
